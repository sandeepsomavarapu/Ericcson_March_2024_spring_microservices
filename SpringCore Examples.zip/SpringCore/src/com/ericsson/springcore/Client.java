package com.ericsson.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {// extends Object

	public static void main(String[] args) {
//		Employee emp=new Employee();//tightly coupled
//		System.out.println(emp);//

		// Resource resource = new ClassPathResource("springconfig.xml");
		// BeanFactory factory = new XmlBeanFactory(resource);//lazy initializer
//		Employee emp = (Employee) factory.getBean("emp");
//		System.out.println(emp);

		// eager intializer
		ApplicationContext factory = new ClassPathXmlApplicationContext("springconfig.xml");
		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp);
		System.out.println(emp.getAddress());

	}

}
