package com.example.demo.controller;

//{
//"productId":222,
//"productName":"oppo79",
//"productPrice":12000,
//"productCategory":"electronics",
//"productBrand":"oppo"
//
//}
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.ExceptionResponse;
import com.example.demo.exceptions.ProductNotFound;
import com.example.demo.models.Product;
import com.example.demo.service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/products") // http://localhost:1234/products
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/insertProduct") // http://localhost:1234/products/insertProduct
	public String saveProduct(@Valid @RequestBody Product product) {
		return service.saveProduct(product);
	}

	@PutMapping("/mergeProduct") // http://localhost:1234/products/mergeProduct
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/removeProduct/{pid}") // http://localhost:1234/products/removeProduct/123
	public String deleteProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.deleteProduct(productId);
	}

	@GetMapping("/getProduct/{pid}") // http://localhost:1234/products/getProduct/123
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.getProduct(productId);
	}

	@GetMapping("/getAll") // // http://localhost:1234/products/getAll
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllBetween/{price1}/{price2}") // // http://localhost:1234/products/getAllBetween/1000/2000
	public List<Product> getAllProductsBetween(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {
		return service.getAllProductsBetween(intialPrice, finalPrice);
	}

	@GetMapping("/getAllByCategory/{cat}") // // http://localhost:1234/products/getAllByCategory/electronics
	public List<Product> getAllProductsByCategory(@PathVariable("cat") String category) {
		return service.getAllProductsByCategory(category);
	}

	@GetMapping("/getAllByBrand/{result}") // // http://localhost:1234/products/getAllByBrand/samsung
	public List<Product> getAllProductsByBrand(@PathVariable("result") String brand) {
		return service.getAllProductsByBrand(brand);
	}


}
