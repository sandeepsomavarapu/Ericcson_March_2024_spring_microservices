package com.example.demo.exceptions;

public class ProductNotFound extends Exception {
	public ProductNotFound(String message) {
		super(message);
	}
}
