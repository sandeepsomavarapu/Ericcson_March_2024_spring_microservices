package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product, Integer> {

	public abstract List<Product> findByProductBrand(String productBrand);

	public abstract List<Product> findByProductCategory(String productCategory);

	public abstract List<Product> findByProductPriceBetween(int intialPrice, int finalPrice);

//	@Query("select p from  Product p where p.productPrice between ?1 and ?2")
//	public abstract List<Product> findByProductPrice(int intialPrice, int finalPrice);

//	public abstract String saveProduct(Product product);
//
//	public abstract Product updateProduct(Product product);
//
//	public abstract String deleteProduct(int productId) throws ProductNotFound;
//
//	public abstract Product getProduct(int productId) throws ProductNotFound;
//
//	public abstract List<Product> getAllProducts();
//
//	public abstract List<Product> getAllProductsBetween(int intialPrice, int finalPrice);
//
//	public abstract List<Product> getAllProductsByCategory(String category);
//
//	public abstract List<Product> getAllProductsByBrand(String brand);
}
