package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.models.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext
	EntityManager em;

	@Override
	public String saveProduct(Product product) {
		em.persist(product);
		return "Product Saved Successfully !!!";
	}

	@Override
	public Product updateProduct(Product product) {
		return em.merge(product);
	}

	@Override
	public String deleteProduct(int productId) {
		em.remove(getProduct(productId));
		return "Product Removed Successfully";
	}

	@Override
	public Product getProduct(int productId) {
		return em.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> query = em.createQuery("select p from Product p", Product.class);

		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		TypedQuery<Product> query = em.createQuery("select p from Product p where p.productPrice between ?1 and ?2",
				Product.class);
		query.setParameter(1, intialPrice);
		query.setParameter(2, finalPrice);
		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		TypedQuery<Product> query = em.createQuery("select p from Product p where p.productCategory=?1", Product.class);
		query.setParameter(1, category);
		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductsByBrand(String brand) {
		TypedQuery<Product> query = em.createQuery("select p from Product p where p.productBrand=?1", Product.class);
		query.setParameter(1, brand);
		return query.getResultList();
	}

}
