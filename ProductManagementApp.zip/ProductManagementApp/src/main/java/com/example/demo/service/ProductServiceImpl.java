package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.ProductNotFound;
import com.example.demo.models.Product;
import com.example.demo.repository.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String saveProduct(Product product) {
		repo.save(product);
		return "Product Saved Successfully...";
	}

	@Override
	public Product updateProduct(Product product) {
		return repo.save(product);
	}

	@Override
	public String deleteProduct(int productId) throws ProductNotFound {
		repo.deleteById(productId);
		return "Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) throws ProductNotFound {
		Optional<Product> optional = repo.findById(productId);
		if (optional.isPresent())
			return optional.get();
		else
			throw new ProductNotFound("ProductId is Invalid");
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsBetween(int intialPrice, int finalPrice) {
		return repo.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return repo.findByProductCategory(category);
	}

	@Override
	public List<Product> getAllProductsByBrand(String brand) {
		return repo.findByProductBrand(brand);
	}

}
