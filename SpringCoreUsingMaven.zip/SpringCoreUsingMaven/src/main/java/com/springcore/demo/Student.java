package com.springcore.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Student {
	private int stuId;
	private String stuName;
	private int stuMarks;
	private String stuBatch;
	@Autowired
	private Address add;

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public int getStuMarks() {
		return stuMarks;
	}

	public void setStuMarks(int stuMarks) {
		this.stuMarks = stuMarks;
	}

	public String getStuBatch() {
		return stuBatch;
	}

	public void setStuBatch(String stuBatch) {
		this.stuBatch = stuBatch;
	}

	public Address getAdd() {
		return add;
	}

	public void setAdd(Address add) {
		this.add = add;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}
}
