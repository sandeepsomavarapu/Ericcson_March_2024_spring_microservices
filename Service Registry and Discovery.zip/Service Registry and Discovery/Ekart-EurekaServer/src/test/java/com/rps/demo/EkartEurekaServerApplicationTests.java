package com.rps.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkartEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
