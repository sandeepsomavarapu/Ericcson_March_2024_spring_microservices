package com.ericsson.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager em = emf.createEntityManager();
		// persist()-->insert,merge()-->update,remove()-->delete,find()-->get/fetch
		// ORM
		// DML-i,u,d-->
		em.getTransaction().begin();
//		Employee emp = new Employee(458, "naresh", 5000, "hr");
//		em.persist(emp);ORM
		Employee emp = em.find(Employee.class, 458);
		System.out.println(emp);
//		emp.setEmpSal(5999);
//		emp.setEmpDesg("trainer");
//		em.merge(emp);

	//	em.remove(emp);

		em.getTransaction().commit();
		System.out.println("Employee Fetched Successfully");

	}

}
